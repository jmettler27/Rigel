package ch.epfl.rigel.astronomy;

import ch.epfl.rigel.coordinates.EquatorialCoordinates;

public class TestMain {

    public static void main (String[] args){

    }
}
